<?php
require_once __DIR__ . '/../includes/auth.php';
exigirLogin();

$jogadores = $pdo->query("SELECT ID, Nome FROM Jogador ORDER BY Nome")->fetchAll();

$id1 = (int)($_GET['j1'] ?? 0);
$id2 = (int)($_GET['j2'] ?? 0);

function mediasJogador(PDO $pdo, int $id): ?array
{
    if (!$id) return null;
    $sql = $pdo->prepare("
        SELECT j.Nome,
            ROUND(AVG(e.Pontos),1) AS Pontos, ROUND(AVG(e.Assistencias),1) AS Assistencias,
            ROUND(AVG(e.Rebotes),1) AS Rebotes, ROUND(AVG(e.Roubos),1) AS Roubos,
            ROUND(AVG(e.Tocos),1) AS Tocos, ROUND(AVG(e.Turnovers),1) AS Turnovers,
            ROUND(AVG(e.Eficiencia),2) AS Eficiencia, ROUND(AVG(e.TS),1) AS TS,
            ROUND(AVG(e.eFG),1) AS eFG, ROUND(AVG(e.Regularidade),1) AS Regularidade
        FROM Jogador j
        LEFT JOIN Estatisticas e ON e.idJogador = j.ID
        WHERE j.ID = ?
        GROUP BY j.ID
    ");
    $sql->execute([$id]);
    return $sql->fetch() ?: null;
}

$j1 = mediasJogador($pdo, $id1);
$j2 = mediasJogador($pdo, $id2);

$pageTitle = "Comparar Jogadores";
require __DIR__ . '/../includes/header.php';
?>
<h1 class="text-2xl font-bold mb-6">Comparação entre Jogadores</h1>

<form method="GET" class="grid md:grid-cols-3 gap-3 mb-8 bg-white dark:bg-gray-800 p-4 rounded-xl shadow items-end">
    <div>
        <label class="block text-sm font-semibold mb-1">Jogador 1</label>
        <select name="j1" class="w-full border rounded p-2">
            <option value="">Selecione</option>
            <?php foreach ($jogadores as $j): ?>
            <option value="<?= $j['ID'] ?>" <?= $id1 == $j['ID'] ? 'selected' : '' ?>><?= htmlspecialchars($j['Nome']) ?></option>
            <?php endforeach; ?>
</select>
</div>
    <div>
        <label class="block text-sm font-semibold mb-1">Jogador 2</label>
        <select name="j2" class="w-full border rounded p-2">
            <option value="">Selecione</option>
            <?php foreach ($jogadores as $j): ?>
            <option value="<?= $j['ID'] ?>" <?= $id2 == $j['ID'] ? 'selected' : '' ?>><?= htmlspecialchars($j['Nome']) ?></option>
            <?php endforeach; ?>
</select>
</div>
    <button type="submit" class="bg-blue-600 hover:bg-blue-700 text-white rounded p-2">Comparar</button>
</form>

<?php if ($j1 && $j2): ?>
<?php
$metricas = [
    'Pontos' => 'Pontos/jogo', 'Assistencias' => 'Assistências/jogo', 'Rebotes' => 'Rebotes/jogo',
    'Roubos' => 'Roubos/jogo', 'Tocos' => 'Tocos/jogo', 'Turnovers' => 'Turnovers/jogo',
    'Eficiencia' => 'Eficiência', 'TS' => 'TS%', 'eFG' => 'eFG%', 'Regularidade' => 'Regularidade'
];
?>
<div class="bg-white dark:bg-gray-800 rounded-xl shadow overflow-x-auto">
<table class="w-full text-sm">
<thead class="bg-gray-100 dark:bg-gray-700">
<tr>
    <th class="p-3 text-left">Métrica</th>
    <th class="p-3 text-center"><?= htmlspecialchars($j1['Nome']) ?></th>
    <th class="p-3 text-center"><?= htmlspecialchars($j2['Nome']) ?></th>
</tr>
</thead>
<tbody>
<?php foreach ($metricas as $campo => $label): ?>
<?php
    $v1 = $j1[$campo] ?? null;
    $v2 = $j2[$campo] ?? null;
    $melhor1 = $v1 !== null && $v2 !== null && $v1 > $v2;
    $melhor2 = $v1 !== null && $v2 !== null && $v2 > $v1;
?>
<tr class="border-t dark:border-gray-700">
    <td class="p-3 font-semibold"><?= $label ?></td>
    <td class="p-3 text-center <?= $melhor1 ? 'text-green-600 font-bold' : '' ?>"><?= $v1 ?? '-' ?></td>
    <td class="p-3 text-center <?= $melhor2 ? 'text-green-600 font-bold' : '' ?>"><?= $v2 ?? '-' ?></td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>
<?php elseif ($id1 || $id2): ?>
<p class="text-gray-400">Selecione os dois jogadores para comparar.</p>
<?php endif; ?>

<?php require __DIR__ . '/../includes/footer.php'; ?>
