<?php
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/functions.php';
exigirPerfil(['Administrador', 'Comissao']);

$message = "";
$erros = [];
$avisos = [];
$sucesso = 0;
$duplicados = 0;
$equipesCriadas = [];

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_FILES['arquivo'])) {
 $arquivo = $_FILES['arquivo'];
 $ext = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));

 if ($arquivo['error'] !== UPLOAD_ERR_OK) {
 $message = "Erro no upload do arquivo.";
 } elseif (!in_array($ext, ['csv', 'xlsx', 'xls'], true)) {
 $message = "Formato inválido. Envie um arquivo.xlsx,.xls ou.csv exportado do Excel.";
 } elseif ($ext !== 'csv') {
 $message = "Este esqueleto processa diretamente arquivos.csv (compatível com Excel). "
. "Para.xlsx/.xls nativos, integre a biblioteca PhpSpreadsheet (composer require phpoffice/phpspreadsheet) "
. "e substitua a leitura abaixo por \$spreadsheet = IOFactory::load(\$arquivo['tmp_name']).";
 } else {
 // Colunas esperadas: Nome; Numero; Posicao; Altura; Peso; DataNascimento; Equipe
 if (($handle = fopen($arquivo['tmp_name'], 'r')) !== false) {
 $linha = 0;
 while (($dados = fgetcsv($handle, 0, ';')) !== false) {
 $linha++;
 if ($linha === 1) continue; // pula cabeçalho

 [$nome, $numero, $posicao, $altura, $peso, $nascimento, $nomeEquipe] =
 array_pad(array_map('trim', $dados), 7, null);

 if (empty($nome)) {
 $erros[] = "Linha $linha: nome em branco, ignorada.";
 continue;
 }

 // Resolve a equipe: cria automaticamente se não existir, ou usa "Sem equipe"
 // se a coluna vier em branco ou com o valor "sem equipe".
 $existiaAntes = false;
 if ($nomeEquipe !== null && $nomeEquipe !== '' && mb_strtolower($nomeEquipe) !== 'sem equipe') {
 $checaEquipe = $pdo->prepare("SELECT ID FROM Equipe WHERE LOWER(Nome) = LOWER(?) LIMIT 1");
 $checaEquipe->execute([$nomeEquipe]);
 $existiaAntes = (bool)$checaEquipe->fetchColumn();
 }
 $idEquipe = obterOuCriarEquipePorNome($pdo, $nomeEquipe);

 if ($nomeEquipe && !$existiaAntes && mb_strtolower($nomeEquipe) !== 'sem equipe'
 && !in_array($nomeEquipe, $equipesCriadas, true)) {
 $equipesCriadas[] = $nomeEquipe;
 }

 // Evita duplicar o mesmo jogador (mesmo nome) dentro da mesma equipe.
 if (jogadorJaExiste($pdo, $nome, $idEquipe)) {
 $avisos[] = "Linha $linha: \"$nome\" já está cadastrado nesta equipe — não foi importado novamente.";
 $duplicados++;
 continue;
 }

 try {
 $sql = $pdo->prepare("
 INSERT INTO Jogador (Nome, Numero, Posicao, Altura, Peso, DataNascimento, idEquipe)
 VALUES (?, ?, ?, ?, ?, ?, ?)
 ");
 $sql->execute([
 $nome,
 $numero ?: null,
 $posicao ?: null,
 $altura ?: null,
 $peso ?: null,
 $nascimento ?: null,
 $idEquipe
 ]);
 $sucesso++;
 } catch (PDOException $e) {
 $erros[] = "Linha $linha: erro ao importar ($nome) — ". $e->getMessage();
 }
 }
 fclose($handle);

 $partesMsg = ["$sucesso jogador(es) importado(s) com sucesso."];
 if ($duplicados > 0) {
 $partesMsg[] = "$duplicados registro(s) ignorado(s) por já existirem.";
 }
 if ($equipesCriadas) {
 $partesMsg[] = "Equipe(s) criada(s) automaticamente: ". implode(', ', $equipesCriadas). ".";
 }
 $message = implode(' ', $partesMsg);
 } else {
 $message = "Não foi possível abrir o arquivo enviado.";
 }
 }
}

$pageTitle = "Importar Jogadores";
require __DIR__ . '/../includes/header.php';
?>
<h1 class="text-2xl font-bold mb-6">Importação de Jogadores (Excel/CSV)</h1>

<?php if ($message !== ""): ?>
<div class="mb-4 p-3 rounded bg-blue-100 text-blue-700 max-w-xl"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if ($avisos): ?>
<div class="mb-4 p-3 rounded bg-yellow-100 text-yellow-800 max-w-xl text-sm">
 <strong>Duplicados ignorados:</strong>
 <ul class="list-disc ml-5">
 <?php foreach ($avisos as $a): ?><li><?= htmlspecialchars($a) ?></li><?php endforeach; ?>
 </ul>
</div>
<?php endif; ?>

<?php if ($erros): ?>
<div class="mb-4 p-3 rounded bg-red-100 text-red-700 max-w-xl text-sm">
 <strong>Erros:</strong>
 <ul class="list-disc ml-5">
 <?php foreach ($erros as $e): ?><li><?= htmlspecialchars($e) ?></li><?php endforeach; ?>
 </ul>
</div>
<?php endif; ?>

<div class="bg-white dark:bg-gray-800 rounded-xl shadow p-8 max-w-xl">
 <p class="text-sm text-gray-500 dark:text-gray-400 mb-4">
 Envie um arquivo <strong>.csv</strong> exportado do Excel (separador <code>;</code>), com as colunas na ordem:
 <br><code>Nome; Numero; Posicao; Altura; Peso; DataNascimento; Equipe</code>
 </p>
 <ul class="text-xs text-gray-500 dark:text-gray-400 mb-4 list-disc ml-5 space-y-1">
 <li>Se a equipe informada não existir ainda no sistema, ela é <strong>criada automaticamente</strong>.</li>
 <li>Se a coluna Equipe vier em branco ou com o valor "sem equipe", o jogador é vinculado à
 categoria <strong>"Sem equipe"</strong> (criada apenas uma vez no sistema).</li>
 <li>Jogadores com o mesmo nome já cadastrados na mesma equipe <strong>não são duplicados</strong> — a linha é ignorada e listada acima.</li>
 </ul>
 <a href="baixar_modelo.php" class="inline-block mb-4 bg-gray-700 hover:bg-gray-800 text-white px-4 py-2 rounded text-sm">
 Baixar planilha modelo (.csv)
 </a>
 <form method="POST" enctype="multipart/form-data" class="space-y-4">
 <input type="file" name="arquivo" accept=".csv,.xlsx,.xls" required class="w-full border rounded p-2 bg-white text-gray-900 placeholder-gray-400">
 <div class="flex gap-3">
 <button type="submit" class="bg-orange-500 hover:bg-orange-600 text-white px-6 py-2 rounded">Importar</button>
 <a href="listar.php" class="bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded">Voltar</a>
 <a href="historico_importacoes.php" class="text-blue-600 hover:underline self-center text-sm">Ver histórico de importações</a>
 </div>
 </form>
</div>

<?php require __DIR__ . '/../includes/footer.php'; ?>
